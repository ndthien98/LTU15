﻿using UnityEngine;
using System.Collections;

public class PlayerCallback : MonoBehaviour {
	
	float speed = 0f;
	float maxSpeed = 0.8f;
	float acceleration = 0.001f;
	float fuel = 300f;
	float score = 0f;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
		if (fuel >= 0) {
			if (speed <= maxSpeed)
			speed += acceleration;	
			
			fuel -= 0.1f;
			score += speed;	
		}
		else { //Out of fuel
			Debug.Log("Out of fuel");
			if (speed > 0) {
				speed -= 0.005f;
				//this.transform.position += new Vector3(0, 0, speed);
				
				score += speed;
				
			}
			else {
				speed = 0f;
				Debug.Log(score.ToString());
			}
		}
		
		Vector3 moveVector = new Vector3(Input.GetAxis("Mouse X"),
											 0,
											 speed);
			
		// Translate Player to the new position
        this.transform.position += moveVector;
		
		// Limit Player's position X
		if (speed > 0) {
			if (this.transform.position.x >= 4.5f)
				this.transform.position = new Vector3(4.5f, this.transform.position.y, this.transform.position.z);
			else if (this.transform.position.x <= -4.5f)
				this.transform.position = new Vector3(-4.5f, this.transform.position.y, this.transform.position.z);
		}
		// Move main Camera position
        Camera.main.transform.position += new Vector3(0, 0, speed);
	}
	
	void OnTriggerEnter(Collider obj) {
		if (obj.name == "Enemy") {
			//Debug.Log("Crashed!");
			speed = 0.0f;
		}
	}
}
