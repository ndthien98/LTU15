﻿using UnityEngine;
using System.Collections;

public class PlayerCallback : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.position += new Vector3(Input.GetAxis("Mouse X"), 0, 0.5f);
        Camera.main.transform.position += new Vector3(0, 0, 0.5f);
	}
	
	void OnTriggerEnter(Collider obj) {
		if (obj.name == "Enemy") {
			Debug.Log("Crashed!");
		}
	}
}
