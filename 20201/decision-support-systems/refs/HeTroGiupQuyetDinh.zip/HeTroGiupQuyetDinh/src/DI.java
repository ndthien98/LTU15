public class DI {
    static int DI1 = 1;
    static int DI2 = 2;
    static int DI3 = 3;
    static int DI4 = 4;
    static int DI5 = 5;
}
