public enum Quantity {
    Universal,
    Predominant,
    Majority,
    Common,
    Particular
}
