public enum Quality {
    Affirmative,
    Negative
}
